import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CloseActionScreenEvent } from 'lightning/actions';
import generateAppPack from '@salesforce/apex/GenerateAppPack.generateAppPack';

/**
 * LWC for generating a new app pack request
 */
export default class GenerateAppPack extends LightningElement {
  /**
   * Wired Opportunity ID
   */
  @api recordId;

  /**
   * Keeps track of LWC loading spinner
   */
  @track loading;

  /**
   * Errors recorded from the send
   */
  @track error;

  /**
   * Cancels the action and closes the window
   */
  async handleCancel() {
    this.dispatchEvent(new CloseActionScreenEvent());
  }

  /**
   * Attempts to send the App pack request
   */
  async handleConfirm() {
    this.loading = true;

    try {
      await generateAppPack({ opportunityId: this.recordId });

      this.dispatchEvent(new CloseActionScreenEvent());

      this.dispatchEvent(
        new ShowToastEvent({
          title: 'Success',
          message: 'Successfully requested app pack generation',
          variant: 'success'
        })
      );
    } catch (e) {
      this.error = 'Unable to generate app pack: ' + e;
    } finally {
      this.loading = false;
    }
  }
}
