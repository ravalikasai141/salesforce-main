import { LightningElement, api } from 'lwc';

export default class ReviewApplicationSection extends LightningElement {
  @api title;
}
