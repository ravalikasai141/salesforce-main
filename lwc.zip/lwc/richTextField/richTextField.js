import { LightningElement, api } from 'lwc';
import { FlowAttributeChangeEvent } from 'lightning/flowSupport';

export default class RichTextField extends LightningElement {
  @api fieldValue;
  formats = [
    'font',
    'size',
    'bold',
    'italic',
    'underline',
    'strike',
    'list',
    'indent',
    'align',
    'link',
    'image',
    'clean',
    'table',
    'header',
    'color',
    'background'
  ];

  handleChange(event) {
    const attributeChangeEvent = new FlowAttributeChangeEvent('fieldValue', event.target.value);
    this.dispatchEvent(attributeChangeEvent);
  }
}
