import { LightningElement, api, wire } from 'lwc';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getApplicantEmail from '@salesforce/apex/VerificationRequestController.getApplicantEmail';
import sendRequest from '@salesforce/apex/VerificationRequestController.sendRequest';

export default class VerificationRequest extends LightningElement {
  /**
   * Opportunity ID
   */
  @api recordId;

  /**
   * Controls spinner visibility
   */
  loading = true;

  /**
   * Errors recorded from the send
   */
  error;

  /**
   * Wire method to get the applicant email
   */
  email;

  /**
   * Boolean check to determine if feature is available for this student
   */
  invalid;

  /**
   * Fetches the applicants email to present before sending
   */
  @wire(getApplicantEmail, { opportunityId: '$recordId' })
  fetch(result) {
    if (result.data || result.error || result.data === null) {
      this.email = result.data;
      this.error = result.error;
      this.invalid = this.email ? false : true;
      this.loading = false;
    }
  }

  /**
   * Cancels the action and closes the window
   */
  handleCancel() {
    this.dispatchEvent(new CloseActionScreenEvent());
  }

  /**
   * Attempts to send the verification request
   */
  async handleConfirm() {
    this.loading = true;

    try {
      await sendRequest({ opportunityId: this.recordId });

      this.dispatchEvent(new CloseActionScreenEvent());

      this.dispatchEvent(
        new ShowToastEvent({
          title: 'Success',
          message: 'Successfully sent verification request',
          variant: 'success'
        })
      );
    } catch (e) {
      this.error = 'Unable to sent verification request: ' + e;
    } finally {
      this.loading = false;
    }
  }
}
